CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    idade INT CHECK (idade > 0),
    genero VARCHAR(20),
    raca VARCHAR(50),
    historico_criminal TEXT,
    comparecimentos INT DEFAULT 0,
    residencia VARCHAR(150)
);
